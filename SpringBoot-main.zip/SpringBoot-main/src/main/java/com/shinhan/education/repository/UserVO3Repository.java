package com.shinhan.education.repository;

import org.springframework.data.repository.CrudRepository;

import com.shinhan.education.vo2.UserVO3;

public interface UserVO3Repository extends CrudRepository<UserVO3, String>{

}
