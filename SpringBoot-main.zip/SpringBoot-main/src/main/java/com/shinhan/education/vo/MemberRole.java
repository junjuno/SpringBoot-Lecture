package com.shinhan.education.vo;

public enum MemberRole {
	ADMIN, USER, MANAGER
}
