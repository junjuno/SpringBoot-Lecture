package com.shinhan.education.repository;

import org.springframework.data.repository.CrudRepository;

import com.shinhan.education.vo.PDSFile;

public interface PDSFileRepository extends CrudRepository<PDSFile, Long>{

}
