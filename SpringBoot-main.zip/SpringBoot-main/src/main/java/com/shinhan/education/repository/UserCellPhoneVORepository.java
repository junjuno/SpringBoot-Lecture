package com.shinhan.education.repository;

import org.springframework.data.repository.CrudRepository;

import com.shinhan.education.vo2.UserCellPhoneVO;

public interface UserCellPhoneVORepository extends CrudRepository<UserCellPhoneVO, Long>{

}
