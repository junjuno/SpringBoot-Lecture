package com.shinhan.education.repository;

import org.springframework.data.repository.CrudRepository;

import com.shinhan.education.vo2.EnumTypeVO;

public interface EnumTypeVORepository extends CrudRepository<EnumTypeVO, String>{
	
}
