package com.shinhan.education.repository;

import org.springframework.data.repository.CrudRepository;

import com.shinhan.education.vo2.UserCellPhoneVO;
import com.shinhan.education.vo2.UserCellPhoneVO2;

public interface UserCellPhoneVORepository2 extends CrudRepository<UserCellPhoneVO2, Long>{

}
